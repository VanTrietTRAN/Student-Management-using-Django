"""
URL configuration for config project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from django.shortcuts import redirect
from rest_framework import routers
from academic.views import CourseViewSet, ClassViewSet, StudentEnrollmentViewSet, GradeViewSet
from schedule.views import RoomViewSet, TimeSlotViewSet, ScheduleViewSet
from django.conf import settings
from django.conf.urls.static import static

# Tạo router cho REST framework
router = routers.DefaultRouter()
router.register(r'courses', CourseViewSet)
router.register(r'classes', ClassViewSet)
router.register(r'enrollments', StudentEnrollmentViewSet)
router.register(r'grades', GradeViewSet)
router.register(r'rooms', RoomViewSet)
router.register(r'timeslots', TimeSlotViewSet)
router.register(r'schedules', ScheduleViewSet)

from users.views import student_dashboard, teacher_dashboard

urlpatterns = [
    # URLs cho authentication và dashboards
    path('', include('authentication.urls')),  # Chuyển đổi trang chủ thành trang đăng nhập
    path('student/', student_dashboard, name='student_dashboard'),
    path('teacher/', teacher_dashboard, name='teacher_dashboard'),
    
    # URLs cho admin và API
    path('admin/', admin.site.urls),
    path('api/', include(router.urls)),
    path('api-auth/', include('rest_framework.urls')),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
