from rest_framework import serializers
from .models import Room, TimeSlot, Schedule
from academic.serializers import ClassSerializer
from academic.models import Class

class RoomSerializer(serializers.ModelSerializer):
    class Meta:
        model = Room
        fields = '__all__'

class TimeSlotSerializer(serializers.ModelSerializer):
    day_of_week_display = serializers.CharField(source='get_day_of_week_display', read_only=True)
    
    class Meta:
        model = TimeSlot
        fields = '__all__'

class ScheduleSerializer(serializers.ModelSerializer):
    class_scheduled = ClassSerializer(read_only=True)
    room = RoomSerializer(read_only=True)
    time_slot = TimeSlotSerializer(read_only=True)
    class_id = serializers.PrimaryKeyRelatedField(
        source='class_scheduled', queryset=Class.objects.all(), write_only=True
    )
    room_id = serializers.PrimaryKeyRelatedField(
        source='room', queryset=Room.objects.all(), write_only=True
    )
    time_slot_id = serializers.PrimaryKeyRelatedField(
        source='time_slot', queryset=TimeSlot.objects.all(), write_only=True
    )

    class Meta:
        model = Schedule
        fields = '__all__'