from django.db import models
from academic.models import Class
from users.models import Teacher

class Room(models.Model):
    name = models.CharField(max_length=50)
    capacity = models.IntegerField()
    building = models.CharField(max_length=100)
    room_type = models.CharField(max_length=50, choices=[
        ('lecture', 'Lecture Hall'),
        ('lab', 'Laboratory'),
        ('seminar', 'Seminar Room')
    ])
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.building} - {self.name}"

class TimeSlot(models.Model):
    DAY_CHOICES = [
        (0, 'Monday'),
        (1, 'Tuesday'),
        (2, 'Wednesday'),
        (3, 'Thursday'),
        (4, 'Friday'),
        (5, 'Saturday'),
        (6, 'Sunday'),
    ]
    
    day_of_week = models.IntegerField(choices=DAY_CHOICES)
    start_time = models.TimeField()
    end_time = models.TimeField()
    
    class Meta:
        ordering = ['day_of_week', 'start_time']
        unique_together = ['day_of_week', 'start_time', 'end_time']
    
    def __str__(self):
        return f"{self.get_day_of_week_display()} ({self.start_time} - {self.end_time})"

class Schedule(models.Model):
    class_scheduled = models.ForeignKey(Class, on_delete=models.CASCADE, related_name='schedules')
    room = models.ForeignKey(Room, on_delete=models.CASCADE)
    time_slot = models.ForeignKey(TimeSlot, on_delete=models.CASCADE)
    start_date = models.DateField()
    end_date = models.DateField()
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        unique_together = ['room', 'time_slot', 'start_date', 'end_date']
    
    def clean(self):
        from django.core.exceptions import ValidationError
        # Check if the room is available for the given time slot and date range
        overlapping_schedules = Schedule.objects.filter(
            room=self.room,
            time_slot=self.time_slot,
            start_date__lte=self.end_date,
            end_date__gte=self.start_date,
            is_active=True
        ).exclude(pk=self.pk)
        
        if overlapping_schedules.exists():
            raise ValidationError('This room is already scheduled for the given time slot and date range.')
    
    def save(self, *args, **kwargs):
        self.clean()
        super().save(*args, **kwargs)
    
    def __str__(self):
        return f"{self.class_scheduled} - {self.room} - {self.time_slot}"
