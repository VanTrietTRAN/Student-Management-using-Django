from rest_framework import viewsets, permissions
from .models import Room, TimeSlot, Schedule
from .serializers import RoomSerializer, TimeSlotSerializer, ScheduleSerializer

class RoomViewSet(viewsets.ModelViewSet):
    queryset = Room.objects.all()
    serializer_class = RoomSerializer
    permission_classes = [permissions.IsAuthenticated]
    
    def get_queryset(self):
        if self.request.user.is_staff:
            return Room.objects.all()
        return Room.objects.filter(is_active=True)

class TimeSlotViewSet(viewsets.ModelViewSet):
    queryset = TimeSlot.objects.all()
    serializer_class = TimeSlotSerializer
    permission_classes = [permissions.IsAuthenticated]

class ScheduleViewSet(viewsets.ModelViewSet):
    queryset = Schedule.objects.all()
    serializer_class = ScheduleSerializer
    permission_classes = [permissions.IsAuthenticated]
    
    def get_queryset(self):
        user = self.request.user
        if user.is_staff:
            return Schedule.objects.all()
        if hasattr(user, 'teacher'):
            return Schedule.objects.filter(class_scheduled__teacher__user=user)
        if hasattr(user, 'student'):
            return Schedule.objects.filter(class_scheduled__enrollments__student__user=user)
        return Schedule.objects.none()
    
    def perform_create(self, serializer):
        serializer.save()
    
    def perform_update(self, serializer):
        serializer.save()
