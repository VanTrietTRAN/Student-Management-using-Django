from django.contrib import admin
from .models import Room, TimeSlot, Schedule

@admin.register(Room)
class RoomAdmin(admin.ModelAdmin):
    list_display = ('name', 'building', 'capacity', 'room_type', 'is_active')
    list_filter = ('building', 'room_type', 'is_active')
    search_fields = ('name', 'building')

@admin.register(TimeSlot)
class TimeSlotAdmin(admin.ModelAdmin):
    list_display = ('get_day_of_week_display', 'start_time', 'end_time')
    list_filter = ('day_of_week',)
    ordering = ('day_of_week', 'start_time')

@admin.register(Schedule)
class ScheduleAdmin(admin.ModelAdmin):
    list_display = ('class_scheduled', 'room', 'time_slot', 'start_date', 'end_date', 'is_active')
    list_filter = ('is_active', 'start_date', 'end_date')
    search_fields = ('class_scheduled__course__code', 'room__name', 'room__building')
    raw_id_fields = ('class_scheduled', 'room', 'time_slot')
    date_hierarchy = 'start_date'
