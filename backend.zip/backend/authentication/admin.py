from django.contrib import admin
# Registration of the User model is handled in users/admin.py
