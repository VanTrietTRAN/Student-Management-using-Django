from rest_framework import status, permissions
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import AllowAny
from django.contrib.auth import login, logout
from django.shortcuts import render, redirect
from django.contrib import messages
from django.views import View
from .serializers import LoginSerializer, UserSerializer, RegisterSerializer
from django.db import transaction

class RegisterView(View):
    def get(self, request):
        return render(request, 'authentication/register.html')
    
    @transaction.atomic
    def post(self, request):
        serializer = RegisterSerializer(data=request.POST)
        if serializer.is_valid():
            user = serializer.save()
            login(request, user)
            messages.success(request, f'Chào mừng {user.get_full_name() or user.username}! Tài khoản của bạn đã được tạo thành công.')
            if user.user_type == 'student':
                return redirect('student_dashboard')
            elif user.user_type == 'teacher':
                return redirect('teacher_dashboard')
        return render(request, 'authentication/register.html', {'form': serializer})

class LoginView(View):
    def get(self, request):
        if request.user.is_authenticated:
            return self._redirect_by_user_type(request.user)
        return render(request, 'authentication/login.html')
    
    def post(self, request):
        serializer = LoginSerializer(data=request.POST)
        if serializer.is_valid():
            user = serializer.validated_data['user']
            login(request, user)
            messages.success(request, f'Chào mừng trở lại, {user.get_full_name() or user.username}!')
            return self._redirect_by_user_type(user)
        return render(request, 'authentication/login.html', {'error': 'Tên đăng nhập hoặc mật khẩu không chính xác'})
    
    def _redirect_by_user_type(self, user):
        if user.is_superuser:
            return redirect('admin:index')
        elif user.user_type == 'student':
            return redirect('student_dashboard')
        elif user.user_type == 'teacher':
            return redirect('teacher_dashboard')

class LogoutView(View):
    def get(self, request):
        logout(request)
        messages.success(request, 'Đăng xuất thành công!')
        return redirect('authentication:login')

class UserProfileView(APIView):
    def get(self, request):
        serializer = UserSerializer(request.user)
        return Response(serializer.data)
    
    def patch(self, request):
        serializer = UserSerializer(request.user, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)