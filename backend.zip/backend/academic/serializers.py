from rest_framework import serializers
from .models import Course, Class, StudentEnrollment, Grade
from users.serializers import StudentSerializer, TeacherSerializer
from users.models import Teacher

class CourseSerializer(serializers.ModelSerializer):
    class Meta:
        model = Course
        fields = '__all__'

class ClassSerializer(serializers.ModelSerializer):
    course = CourseSerializer(read_only=True)
    teacher = TeacherSerializer(read_only=True)
    course_id = serializers.PrimaryKeyRelatedField(
        queryset=Course.objects.all(), source='course', write_only=True
    )
    teacher_id = serializers.PrimaryKeyRelatedField(
        queryset=Teacher.objects.all(), source='teacher', write_only=True
    )

    class Meta:
        model = Class
        fields = '__all__'

class StudentEnrollmentSerializer(serializers.ModelSerializer):
    student = StudentSerializer(read_only=True)
    class_enrolled = ClassSerializer(read_only=True)
    grade = serializers.SerializerMethodField()

    class Meta:
        model = StudentEnrollment
        fields = '__all__'
    
    def get_grade(self, obj):
        try:
            return GradeSerializer(obj.grade).data
        except Grade.DoesNotExist:
            return None

class GradeSerializer(serializers.ModelSerializer):
    class Meta:
        model = Grade
        fields = '__all__'
        read_only_fields = ('total_score', 'grade_letter', 'update_date')