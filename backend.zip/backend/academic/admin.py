from django.contrib import admin
from .models import Course, Class, StudentEnrollment, Grade

@admin.register(Course)
class CourseAdmin(admin.ModelAdmin):
    list_display = ('code', 'name', 'credits')
    search_fields = ('code', 'name')
    ordering = ('code',)

@admin.register(Class)
class ClassAdmin(admin.ModelAdmin):
    list_display = ('course', 'teacher', 'semester', 'year', 'is_active')
    list_filter = ('semester', 'year', 'is_active')
    search_fields = ('course__code', 'course__name', 'teacher__user__username')
    raw_id_fields = ('course', 'teacher')

@admin.register(StudentEnrollment)
class StudentEnrollmentAdmin(admin.ModelAdmin):
    list_display = ('student', 'class_enrolled', 'enrollment_date', 'status')
    list_filter = ('status', 'enrollment_date')
    search_fields = ('student__user__username', 'class_enrolled__course__code')
    raw_id_fields = ('student', 'class_enrolled')
    date_hierarchy = 'enrollment_date'

@admin.register(Grade)
class GradeAdmin(admin.ModelAdmin):
    list_display = ('enrollment', 'midterm_score', 'final_score', 'total_score', 'grade_letter', 'update_date')
    list_filter = ('grade_letter', 'update_date')
    search_fields = ('enrollment__student__user__username', 'enrollment__class_enrolled__course__code')
    readonly_fields = ('total_score', 'grade_letter', 'update_date')
    raw_id_fields = ('enrollment',)
