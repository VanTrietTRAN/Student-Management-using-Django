from django.db import models
from users.models import Student, Teacher

class Course(models.Model):
    code = models.CharField(max_length=10, unique=True)
    name = models.CharField(max_length=200)
    credits = models.IntegerField()
    description = models.TextField(blank=True)
    
    def __str__(self):
        return f"{self.code} - {self.name}"

class Class(models.Model):
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name='classes')
    teacher = models.ForeignKey(Teacher, on_delete=models.SET_NULL, null=True, related_name='teaching_classes')
    semester = models.CharField(max_length=20)  # e.g., "Fall 2025"
    year = models.IntegerField()
    max_students = models.IntegerField(default=40)
    is_active = models.BooleanField(default=True)
    
    class Meta:
        verbose_name_plural = "Classes"
    
    def __str__(self):
        return f"{self.course.code} - {self.semester} {self.year}"

class StudentEnrollment(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE, related_name='enrollments')
    class_enrolled = models.ForeignKey(Class, on_delete=models.CASCADE, related_name='enrollments')
    enrollment_date = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=20, choices=[
        ('enrolled', 'Enrolled'),
        ('dropped', 'Dropped'),
        ('completed', 'Completed')
    ])
    
    class Meta:
        unique_together = ['student', 'class_enrolled']
    
    def __str__(self):
        return f"{self.student} - {self.class_enrolled}"

class Grade(models.Model):
    enrollment = models.OneToOneField(StudentEnrollment, on_delete=models.CASCADE, related_name='grade')
    midterm_score = models.DecimalField(max_digits=4, decimal_places=2, null=True, blank=True)
    final_score = models.DecimalField(max_digits=4, decimal_places=2, null=True, blank=True)
    other_score = models.DecimalField(max_digits=4, decimal_places=2, null=True, blank=True)
    total_score = models.DecimalField(max_digits=4, decimal_places=2, null=True, blank=True)
    grade_letter = models.CharField(max_length=2, blank=True)
    update_date = models.DateTimeField(auto_now=True)
    
    def calculate_total(self):
        if self.midterm_score and self.final_score:
            self.total_score = self.midterm_score * 0.3 + self.final_score * 0.7
            if self.total_score >= 8.5:
                self.grade_letter = 'A'
            elif self.total_score >= 7.0:
                self.grade_letter = 'B'
            elif self.total_score >= 5.5:
                self.grade_letter = 'C'
            elif self.total_score >= 4.0:
                self.grade_letter = 'D'
            else:
                self.grade_letter = 'F'
    
    def save(self, *args, **kwargs):
        self.calculate_total()
        super().save(*args, **kwargs)
    
    def __str__(self):
        return f"{self.enrollment} - {self.grade_letter}"
