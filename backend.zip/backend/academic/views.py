from rest_framework import viewsets, permissions
from rest_framework.decorators import action
from rest_framework.response import Response
from django.db.models import Q
from .models import Course, Class, StudentEnrollment, Grade
from .serializers import CourseSerializer, ClassSerializer, StudentEnrollmentSerializer, GradeSerializer
from users.models import Teacher, Student

class CourseViewSet(viewsets.ModelViewSet):
    queryset = Course.objects.all()
    serializer_class = CourseSerializer
    permission_classes = [permissions.IsAuthenticated]
    
    def get_queryset(self):
        if self.request.user.is_staff:
            return Course.objects.all()
        return Course.objects.filter(
            Q(classes__teacher__user=self.request.user) |
            Q(classes__enrollments__student__user=self.request.user)
        ).distinct()

class ClassViewSet(viewsets.ModelViewSet):
    queryset = Class.objects.all()
    serializer_class = ClassSerializer
    permission_classes = [permissions.IsAuthenticated]
    
    def get_queryset(self):
        user = self.request.user
        if user.is_staff:
            return Class.objects.all()
        if hasattr(user, 'teacher'):
            return Class.objects.filter(teacher__user=user)
        if hasattr(user, 'student'):
            return Class.objects.filter(enrollments__student__user=user)
        return Class.objects.none()
    
    @action(detail=True, methods=['get'])
    def students(self, request, pk=None):
        class_obj = self.get_object()
        enrollments = class_obj.enrollments.all()
        serializer = StudentEnrollmentSerializer(enrollments, many=True)
        return Response(serializer.data)

class StudentEnrollmentViewSet(viewsets.ModelViewSet):
    queryset = StudentEnrollment.objects.all()
    serializer_class = StudentEnrollmentSerializer
    permission_classes = [permissions.IsAuthenticated]
    
    def get_queryset(self):
        user = self.request.user
        if user.is_staff:
            return StudentEnrollment.objects.all()
        if hasattr(user, 'teacher'):
            return StudentEnrollment.objects.filter(class_enrolled__teacher__user=user)
        if hasattr(user, 'student'):
            return StudentEnrollment.objects.filter(student__user=user)
        return StudentEnrollment.objects.none()

class GradeViewSet(viewsets.ModelViewSet):
    queryset = Grade.objects.all()
    serializer_class = GradeSerializer
    permission_classes = [permissions.IsAuthenticated]
    
    def get_queryset(self):
        user = self.request.user
        if user.is_staff:
            return Grade.objects.all()
        if hasattr(user, 'teacher'):
            return Grade.objects.filter(enrollment__class_enrolled__teacher__user=user)
        if hasattr(user, 'student'):
            return Grade.objects.filter(enrollment__student__user=user)
        return Grade.objects.none()
