from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from authentication.models import User
from .models import Student, Teacher

class StudentInline(admin.StackedInline):
    model = Student
    can_delete = False
    verbose_name_plural = 'student'

class TeacherInline(admin.StackedInline):
    model = Teacher
    can_delete = False
    verbose_name_plural = 'teacher'

class CustomUserAdmin(UserAdmin):
    inlines = (StudentInline, TeacherInline)
    list_display = ('username', 'email', 'first_name', 'last_name', 'is_staff')
    search_fields = ('username', 'first_name', 'last_name', 'email')

# Unregister the default User admin if it was registered
if User in admin.site._registry:
    admin.site.unregister(User)

# Register with our custom admin
admin.site.register(User, CustomUserAdmin)

@admin.register(Student)
class StudentAdmin(admin.ModelAdmin):
    list_display = ('student_id', 'get_full_name')
    search_fields = ('student_id', 'user__username', 'user__first_name', 'user__last_name')
    search_fields = ('student_id', 'user__username', 'user__first_name', 'user__last_name')
    
    def get_full_name(self, obj):
        return obj.user.get_full_name()
    get_full_name.short_description = 'Full Name'

@admin.register(Teacher)
class TeacherAdmin(admin.ModelAdmin):
    list_display = ('teacher_id', 'get_full_name', 'department', 'phone')
    search_fields = ('teacher_id', 'user__username', 'user__first_name', 'user__last_name', 'department')
    
    def get_full_name(self, obj):
        return obj.user.get_full_name()
    get_full_name.short_description = 'Full Name'
