from django.shortcuts import render
from django.contrib.auth.decorators import login_required, user_passes_test

def is_student(user):
    return user.user_type == 'student'

def is_teacher(user):
    return user.user_type == 'teacher'

@login_required
@user_passes_test(is_student)
def student_dashboard(request):
    return render(request, 'users/student_dashboard.html')

@login_required
@user_passes_test(is_teacher)
def teacher_dashboard(request):
    return render(request, 'users/teacher_dashboard.html')
